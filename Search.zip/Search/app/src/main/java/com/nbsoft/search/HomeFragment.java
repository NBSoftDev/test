package com.nbsoft.search;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.nbsoft.search.Adapter.MyAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class HomeFragment extends Fragment {

    public static String DataLoader ="";
    GridView gridview;

    public static ArrayList<HashMap<String,String>> arrayList = new ArrayList<>();
    public static MyAdapter myAdapter;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        gridview = view.findViewById(R.id.gridview);


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, DataLoader, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            JSONArray jsonArray =  response.getJSONArray("quotes");

                            for ( int quote = 0; quote<jsonArray.length(); quote++){

                                JSONObject jsonObject =jsonArray.getJSONObject(quote);

                                String Mquote = jsonObject.getString("quote");
                                String Mautho = jsonObject.getString("author");

                                HashMap<String,String>hashMap = new HashMap<>();
                                hashMap.put("quotes", Mquote);
                                hashMap.put("author", Mautho);
                                arrayList.add(hashMap);

                            }


                            myAdapter = new MyAdapter(arrayList);
                            gridview.setAdapter(myAdapter);
                            myAdapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(jsonObjectRequest);







        return view;
    }

    public static void FilterData(String newText, Context context) {
        ArrayList<HashMap<String,String>> arrayList1 = new ArrayList<>();
        for (HashMap<String,String>hashMap : arrayList){
            hashMap.get("quotes").toLowerCase().contains(newText.toLowerCase());
            arrayList1.add(hashMap);

            if (arrayList1.isEmpty()){
                Toast.makeText(context, "No Data", Toast.LENGTH_SHORT).show();
            } else {
                myAdapter.FilterData(arrayList1);
            }
        }

    }


}